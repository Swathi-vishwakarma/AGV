#!/usr/bin/env python3

import RPi.GPIO as GPIO
import time
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

from gpiozero import Motor, GPIOZeroError

# Set GPIO pin numbers for left motor
LEFT_FORWARD_PIN = 17
LEFT_BACKWARD_PIN = 18

# Set GPIO pin numbers for right motor
RIGHT_FORWARD_PIN = 27
RIGHT_BACKWARD_PIN = 22

# Set GPIO mode to use GPIO pin numbering
GPIO.setmode(GPIO.BCM)

# Set GPIO pins as output
GPIO.setup(LEFT_FORWARD_PIN, GPIO.OUT)
GPIO.setup(LEFT_BACKWARD_PIN, GPIO.OUT)
GPIO.setup(RIGHT_FORWARD_PIN, GPIO.OUT)
GPIO.setup(RIGHT_BACKWARD_PIN, GPIO.OUT)

# Create PWM objects for left and right motors
left_forward_pwm = GPIO.PWM(LEFT_FORWARD_PIN, 100)  # Frequency = 100 Hz
left_backward_pwm = GPIO.PWM(LEFT_BACKWARD_PIN, 100)  # Frequency = 100 Hz
right_forward_pwm = GPIO.PWM(RIGHT_FORWARD_PIN, 100)  # Frequency = 100 Hz
right_backward_pwm = GPIO.PWM(RIGHT_BACKWARD_PIN, 100)  # Frequency = 100 Hz

# Initialize motor speeds
left_speed = 0
right_speed = 0

def set_motor_speeds(left_speed, right_speed):
    # Set the speed of the left motor
    if left_speed >= 0:
        left_forward_pwm.start(left_speed)
        left_backward_pwm.stop()
        print("Left motor: Forward")
    else:
        left_forward_pwm.stop()
        left_backward_pwm.start(abs(left_speed))
        print("Left motor: Backward")
    # Set the speed of the right motor
    if right_speed >= 0:
        right_forward_pwm.start(right_speed)
        right_backward_pwm.stop()
        print("Right motor: Forward")
    else:
        right_forward_pwm.stop()
        right_backward_pwm.start(abs(right_speed))
        print("Right motor: Backward")

class MotorController(Node):
    def __init__(self):
        super().__init__('motor_controller')
        self.subscription = self.create_subscription(Twist, 'cmd_vel', self.cmd_vel_callback, 10)

    def cmd_vel_callback(self, msg):
        # Extract linear and angular velocities from Twist message
        linear_velocity = msg.linear.x
        angular_velocity = msg.angular.z

        # Calculate left and right motor speeds based on the velocities
        left_speed = linear_velocity - angular_velocity
        right_speed = linear_velocity + angular_velocity

        # Set the motor speeds
        set_motor_speeds(left_speed, right_speed)

def main(args=None):
    rclpy.init(args=args)
    motor_controller = MotorController()
    rclpy.spin(motor_controller)

    # Clean up GPIO and PWM resources
    left_forward_pwm.stop()
    left_backward_pwm.stop()
    right_forward_pwm.stop()
    right_backward_pwm.stop()
    GPIO.cleanup()

if __name__ == '__main__':
    main()
