#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from gpiozero import Motor, GPIOZeroError

# Define your motor pin numbers here
motor1_pin1 = 17
motor1_pin2 = 18
motor2_pin1 = 27
motor2_pin2 = 22

class MotorNode(Node):
    def __init__(self):
        super().__init__('teleop_node')

        # Create a subscriber for the /cmd_vel topic
        self.subscription = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.cmd_vel_callback,
            10  # Adjust the queue size as per your requirements
        )
        self.subscription  # Prevent unused variable warning

        # Initialize your motors using the specified pin numbers
        try:
            # Initialize your motors with your specific pin numbers
            self.motor1 = Motor(forward=motor1_pin1, backward=motor1_pin2)
            self.motor2 = Motor(forward=motor2_pin1, backward=motor2_pin2)
        except GPIOZeroError:
            print("Failed to initialize motors. Make sure the GPIO pins are correct.")

    def cmd_vel_callback(self, msg):
        # Extract linear and angular velocity values from the Twist message
        linear_vel = msg.linear.x
        angular_vel = msg.angular.z

        # Calculate the individual motor speeds based on linear and angular velocity
        left_motor_speed = linear_vel - angular_vel
        right_motor_speed = linear_vel + angular_vel

        # Control the left and right motors based on the calculated speeds
        if left_motor_speed > 0:
            self.motor1.forward(speed=left_motor_speed)
        else:
            self.motor1.backward(speed=abs(left_motor_speed))

        if right_motor_speed > 0:
            self.motor2.forward(speed=right_motor_speed)
        else:
            self.motor2.backward(speed=abs(right_motor_speed))

def main(args=None):
    rclpy.init(args=args)

    motor_node = MotorNode()

    rclpy.spin(motor_node)

    motor_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

