echo "No flash step"
echo "Please find library and includes inside firmware/build folder"