* The track used in the simulations (`models/track2`) may not be in real life proportions.

* Calibration of the parameters by the user is quite important in order to make the node work. 

